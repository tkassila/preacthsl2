import { Component } from 'preact';

class Config extends Component {

    static bDebug = true;

    /*
    static HSLLSERVICEURI = {
      HSL: 'hsl',
      WALTTI: 'waltti',
      FINLAND: 'finland'
    };
    */
   static HSLLSERVICEURI_HSL = 'hsl';
   static HSLLSERVICEURI_WALTTI = 'waltti';
   static HSLLSERVICEURI_FINLAND = 'finland';

    constructor(props)
    {
      super(props);
      this.state = {          

      }
    }
  
    render() {
      return (
        <div>
        </div>  
      );} 
  }

  export default Config;