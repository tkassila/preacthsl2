import React, { Component } from 'preact';
import Address from '../Address.js';
import NearStop from './NearStop';
import axios from 'axios';
// import gql from "apollo-boost";
import Checkbox from '../../components/Checkbox';
import NearestStops from '../NearestStops';
import Config from '../../util/Config';

// import ApolloClient from "apollo-boost";
// import gql from "apollo-boost";
// import { withApollo } from 'react-apollo';
// import { url } from 'inspector';
// import { type } from 'os';

class SearchAndListAddressStops extends Component 
{
   // address_search_url = "https://api.digitransit.fi/geocoding/v1/search?text=";
    hsl_baseurl = null;
    // address_search_url = "http://localhost:8080/hsl/geocoding/v1/search?text=";
    address_search_url = null;
    prev_features = null;
    nearestopsmap = null;
         
  
    constructor(props) {
        super(props);
        if (Config.bDebug)
        {
          console.log("SearchAndListAddressStops constructor(props)");
          console.log(props);
          console.log("SearchAndListAddressStops props.neareststops");
          console.log(props.neareststops);
        }
        this.hsl_baseurl = "http://localhost:8080/hsl/";
        this.address_search_url = this.hsl_baseurl +"geocoding/v1/search?text=";
        this.nearestopsmap = null;
        
        this.state = {
            searchstops: (props.neareststops != null),
            address: props.address,
            addressfeatures: props.addressfeatures,
            neareststops: props.neareststops,
            seeKAllStopTimes: false,
            uncheckCheckBox: false,
            distance: props.distance,
            alladdresses: props.alladdresses,
            loading: false
        }
     
        if (this.props.client)
        {
            this.client = this.props.client;
            if (Config.bDebug)
            console.log("SearchAndListAddressStops this.props.client");
        }

        if (Config.bDebug)
        {
            if (this.client)
              console.log("client=" +this.client);
            else
              console.log("null: client" );
        }

      //  this.makeGetQuery();
    }

    shouldComponentUpdate(nextProps, nextState) { 
      return true;
    }

    componentWillMount()
    {
       /*
        if (this.props.longitude !== null && this.props.latitue !== null)
        {
             this.makeApolloCallForNearestStopsAfterLongitudeAndLatitue(this.props.longitude, this.props.latitue);
        }
        else
        if (this.props.address)
        {
            this.makeApolloCallForNearestStops(this.props.addressfeatures, this.props.distance);
            this.setState( {
                searchstops: true,
                address: this.props.address,
                addressfeatures: this.props.addressfeatures,
	            	distance: this.props.distance
            });            
        }
        */
    }

    componentWillReceiveProps(nextProps) 
    {
      /*
      if (this.props.longitude !== nextProps.longitude 
        && this.props.latitue !== nextProps.latitue)
      {
        ?*
        if (nextProps.longitude && nextProps.latitue)
        {
          *?
           this.makeApolloCallForNearestStopsAfterLongitudeAndLatitue(nextProps.longitude, nextProps.latitue);      
       // }
      }
      else
      {
         if (this.props.address !== nextProps.address) {
           this.setState({address: nextProps.address, neareststops: null});
        }        
        if (this.props.addressfeatures !== nextProps.addressfeatures) {
            this.setState({addressfeatures: nextProps.addressfeatures, neareststops: null});
          }
          if (this.props.addresssselected !== nextProps.addresssselected) {
            this.setState({addresssselected: nextProps.addresssselected, neareststops: null});
          }        
         this.makeApolloCallForNearestStops(nextProps.addressfeatures)        
      }
      */
     }

     makeApolloCallForNearestStops(addressfeatures)
    {
      if (Config.bDebug)
      {
        console.log("makeApolloCallForNearestStops 1 1" );
        console.log(addressfeatures );
      }
        let coordinates = null;
        
        coordinates = addressfeatures.map((feature) => { return (feature && feature.geometry && feature.geometry.coordinates ? feature.geometry.coordinates : null); });
        if (Config.bDebug)
        console.log(coordinates );
        let longitude = coordinates[0][1];
        let latitude = coordinates[0][0];
        this.makeApolloCallForNearestStopsAfterLongitudeAndLatitue(longitude, latitude)
    }

    makeApolloCallForNearestStopsAfterLongitudeAndLatitue(longitude, latitude)
    {
      if (Config.bDebug)
      {
        console.log("longitude ");
        console.log(longitude );
        console.log("latitude ");
        console.log(latitude );
      }
        this.nearestopsmap = null;        
        this.setState({seeKAllStopTimes: false, neareststops: null});
        /*
        fetch('https://api.github.com/gists', {
    method: 'post',
    body: JSON.stringify({
        description: 'Fetch API Post example',
        public: true,
        files: {
          'test.js': {
            content: 'kissa'
          }
        }
      })
  }).then(function(response) {
    return response.json();
  }).then(function(data) {
    console.error('Created Gist:', data.html_url);
  });

  console.log("makeApolloCallForNearestStops 2" );
  */

  const options = {
    method: 'POST',
    data: `{
      stopsByRadius(lat:60.199,lon:24.938,radius:500) {
        edges {
          node {
            stop { 
              gtfsId 
              name
            }
            distance
          }
        }
      }
    }`,
    // credentials: 'include',
    headers: { "Content-Type": "application/graphql"}
  };
  
  let data = `{ stop(id: "HSL:1040129") {
    name
    lat
    lon
    wheelchairBoarding
  }  
}`;
  // let body = JSON.stringify(data);
  let body1 = `nearest(lat: 60.19414, lon: 25.02965, maxResults: 3, 
    trrt
  dddd
		      }`;
  
    let distanceparam = this.props.distance;
    if (distanceparam == null || distanceparam.trim().length == 0)
      distanceparam = 800;
	// maxResults: 10,
  let body = `{ nearest(lat: ` +longitude +`, lon: ` +latitude +`,  
    maxDistance: ` +distanceparam +`, filterByPlaceTypes: [STOP, BIKE_PARK]) {
    edges {
      node {
          place {
            lat
            lon
            ...on Stop {
              name
              gtfsId
              code
              desc
              locationType              
            }
            ...on BikePark {
              name
              bikeParkId
              spacesAvailable
            }
          }
          distance
      }
    }
  }
}`;

if (Config.bDebug)
{
  console.log("body");
  console.log(body);
}
  // http://localhost:8080/hsl/geocoding/v1/search
  /*
  fetch( this.hsl_baseurl +'routing/v1/routers/hsl/index/graphql', {
    method: 'POST',
    */
 //   headers: {"Content-Type": "application/graphql",  'Accept': '*/*'},
  /*  body: body })
    .then(response => { return response.json();})
    .then(responseData => {console.log(responseData.data); return responseData.data;})
    .then(data => { 
      console.log("data");
      console.log(data); }
      )
    .catch((error) => {
        console.error("error");
        console.error(error);
    });
    */

   if (Config.bDebug)
      console.log("fetch url: " +this.hsl_baseurl +'routing/v1/routers/' +NearestStops.localHSLUri+ '/index/graphql');

   fetch( this.hsl_baseurl +'routing/v1/routers/' +NearestStops.localHSLUri+ '/index/graphql', {
    method: 'POST',
    headers: {"Content-Type": "application/graphql",  'Accept': '*/*'},
    body: body })
    .then(response => { return response.json();})
    .then(responseData => {if (Config.bDebug) console.log(responseData.data); return responseData.data;})
    .then(data => { 
      if (Config.bDebug)
      {
      console.log("data");
      console.log(data);
      console.log(data.nearest.edges);
      }
      this.setState({ uncheckCheckBox: true, neareststops: data.nearest.edges }) }
      )
    .catch((error) => {
        console.error("error");
        console.error(error);
    });
  
/*
        fetch('http://localhost:8080/hsl/graphql/hsl', {
            method: 'post',
            headers: {"Content-Type": "application/graphql"},
            body: `{ stop(id: "HSL:1040129") {
                name
                lat
                lon
                wheelchairBoarding
              }  
            }`}
            ).then((response) => response.json())
           .then((responseJson) => {
            console.error("responseJson");
             return responseJson;
           })
           .catch((error) => {
            console.error("responseJson error");
             console.error(error);
           } );     
          */
         if (Config.bDebug)
           console.log("makeApolloCallForNearestStops 3" );
        this.setState({ latitude: latitude, longitude: longitude });
        this.props.coordinateschanged(latitude, longitude);
    }

     makeApolloCallForNearestStops2(addressfeatures)
     {
      if (Config.bDebug)
        console.log("makeApolloCallForNearestStops 2 1" );
        if (!addressfeatures)
            return;
            if (Config.bDebug)
            console.log("makeApolloCallForNearestStops before http CALL");

        // this.client.setUrl("https://api.digitransit.fi/graphql/hsl");
        /*
        this.client
            .query({
            query: gql`
            {
                stopsByRadius(lat:60.201706,lon:24.918506,radius:500) {
                  edges {
                    node {
                      stop { 
                        gtfsId 
                        name
                      }
                      distance
                    }
                  }
                }
            }        `
        })
      .then(result => console.log(result));
      */

      /*
     axios.post('https://api.digitransit.fi/graphql/hsl', { query: `{ 
        stopsByRadius(lat:60.201706,lon:24.918506,radius:1500) {
          edges {
            node {
              stop { 
                gtfsId 
                name
              }
              distance
            }
          }
        }
      }`,
      headers: { 'Content-Type': 'application/graphql' } })
      .then(function (response) {
        console.log("response");
        console.log(response);
      })
      .catch(function (error) {
        console.log("error");  
        console.log(error);
      });
      */

     var xhr = new XMLHttpRequest()
     //xhr.open("POST", 'https://api.digitransit.fi/graphql/hsl'  )
     xhr.open("POST", 'http://localhost:8080/' +NearestStops.localHSLUri+ '/graphql/hsl'  )
     xhr.setRequestHeader('Content-Type', 'application/graphql' );
     xhr.withCredentials = false;
     xhr.onload = function(e){
        console.log("onload=>");
       if (xhr.readyState === 4){
         if (xhr.status === 200){
          if (Config.bDebug)
            console.log("onload 1 =>");
           var data = JSON.parse(xhr.response);
           if (Config.bDebug)
           console.log("onload 2 =>");
           if (Config.bDebug)
           console.log("onload 3 data => " +data);
           /*
           this.setState({
             story: story,
             storyLength: story.length,
             currentChapter: story[0]
           })
           */
         } else {
           console.error(xhr.statusText)
         }
       }
     }; // .bind(this);
 
     xhr.onprogress = function () {
        console.log('LOADING', xhr.status);
    };
  
    xhr.onerror = function(e){
       console.error(xhr.statusText)
     };

     if (Config.bDebug)
     console.log("makeApolloCallForNearestStops before http CALL 2");

     xhr.send( `{ 
        stopsByRadius(lat:60.201706,lon:24.918506,radius:1500) {
          edges {
            node {
              stop { 
                gtfsId 
                name
              }
              distance
            }
          }
        }
      }`);
    
      if (Config.bDebug)
    console.log("makeApolloCallForNearestStops AFTER  http CALL");
    }

    /*
    componentDidMount() {
        this.makeGetQuery();
    }
    */

    /*
    componentDidUpdate()
    {
        this.makeGetQuery();
    }
    */

    makeGetQuery()
    {
        if (!this.props.searchstops && this.props.address.length == 0)
            return;
        if (this.props.address.length == 0)
            return;
        if (Config.bDebug)
        console.log("before: axios:" );
        const test = this.address_search_url +this.props.address;
        console.log("url:" +test  );
         const decodedurl = this.address_search_url +encodeURIComponent(this.props.address);
         if (Config.bDebug)
         console.log("decodedurl:" +decodedurl  );
        axios.get(decodedurl)
            .then(response => this.handleResponseData(response));
    }

    handleResponseData(response)
    {
      let firstAddress = this.props.address;
      let founded = seekRigthAddressFromResponse(response, firstAddress);
      while(!founded && firstAddress != null )
      {
        founded = seekRigthAddressFromResponse(response, firstAddress);
      }
    }

    seekRigthAddressFromResponse(response, address)
    {
            let i = 0;
            let bSearch = false;
            const features = response.data.features;
            let feature, coordinates, street;
            let bExactAdressFound = false;

            for (i in features) {
                feature = features[i];
                coordinates = feature.geometry.coordinates;
                street = feature.properties.name;      
                if (Config.bDebug)      
                console.log("coordinates:" +coordinates);
                if (Config.bDebug)
                console.log("street:" +street);
                if (street != null && street.toString() == this.props.address.toString())
                {
                    bExactAdressFound = true;
                    if (Config.bDebug)
                    console.log("bExactAdressFound:" +bExactAdressFound);
                    break;
                }
            } 

            if (bExactAdressFound)
            {
              if (Config.bDebug)
                console.log("bExactAdressFound2:" +bExactAdressFound);
                let addressfeature = new Object();
               if (address != null && address.length > 0)
                    bSearch = true;
                let afeatures = [ feature ];
                coordinates = feature.geometry.coordinates;
                street = feature.properties.name;
                this.setState({ searchstops: bSearch, addressfeatures: afeatures } );
                return true;
            }
            else
            {
              if (Config.bDebug)
                console.log("features for 2:");
                /*
                for (i in features) {
                    feature = features[i];
                    coordinates = feature.geometry.coordinates;
                    street = feature.properties.name;            
                    console.log("coordinates:" +coordinates);
                    console.log("street:" +street);
                }     
                */
                if (this.props.address.length > 0)
                    bSearch = true;
                this.setState({ searchstops: bSearch, addressfeatures: features } );
                return false;       
            }
            //console.log(coordinates);
         //   this.render();
    }

    addresssSelected = (addressparam, distance) => {      
      if (Config.bDebug)  
        console.log("addresssSelected.addressparam=" +addressparam);
      if (!distance || distance == '')
        distance = '1500';
        
        this.setState({
            address: addressparam,
            searchstops: false,
            addressfeatures: null,
	          distance: distance
        });
        let bSearch = false;
    
        if (Config.bDebug)
        {
        console.log("addressparam=" +addressparam);
        console.log("bSearch=" +bSearch);
        console.log("distance=" +distance);
        }

	this.setState({ ... this.state, distance: distance });
	
     //   React.render(this, document.getElementById('div.ListAddresses'));
       /* axios.get("https://api.digitransit.fi/geocoding/v1/search?text=kamppi&size=1")
        .then(response =>  console.log(response.data));
*/
//        then(response => this.setState({username: response.data.name}))
      if (Config.bDebug)
        console.log("bSearch2");
      }

      handleChecboxShowAllStopTimes = (id, label, isChecked) =>
      {
        if (Config.bDebug)
        {
        console.log("handleChecboxShowAllStopTimes");
        console.log("id");
        console.log(id);
        console.log("label");
        console.log(label);
        console.log("isChecked");
        console.log(isChecked);
        }

        if (isChecked && this.nearestopsmap != null ) 
        {
            this.setState({seeKAllStopTimes: true});
        }
        else
        if (!isChecked && this.nearestopsmap != null ) 
        {
            this.setState({seeKAllStopTimes: false});
        }
      }

    render(props, state) 
    {      
        const search = state.searchstops;
        if (Config.bDebug)
        {
        console.log("SearchAndListAddressStops::render(props, state)");
        console.log("rendering");
        console.log("search="+search);
        console.log("state.addressfeatures");
        console.log(state.addressfeatures);
        }
        // const features2 = this.state.addressfeatures;        
        let coordinates, street;
       if (search && state.addressfeatures /* && (this.prev_feature == null 
          || this.prev_feature != this.state.addressfeatures) */)
       {
           /*
           const features2 = this.state.addressfeatures.map((feature) => {
            return (
            <p>{feature.properties.name +" " +feature.geometry.coordinates}</p>
           );                    
           } 
        );
        */
            let childrenSize = state.addressfeatures.length;
            console.log("childrenSize:" +childrenSize);
            let children = state.addressfeatures;
            let features2 = null;
            /* features2 = state.addressfeatures.map((feature) => {
                return (
                  <Address address={feature.properties.name +" " +feature.geometry.coordinates} 
                  addresssselected={null}/>
               );                    
               } 
               );
               */
               if (Config.bDebug)
               console.log("this.state.neareststops:" +state.neareststops);
               
            const loading = this.state.loading;
            let loadingComp = null;
            if (loading && features2 == null)
               loadingComp = <h3>Ladataan...</h3>;            

               /*
            coordinates = feature.geometry.coordinates;
            street = feature.properties.name;            
            console.log("coordinates:" +coordinates);
            console.log("street:" +street);
            */
           if (Config.bDebug)
           console.log("this.state.neareststops:" +state.neareststops);
            if (state.neareststops)
              this.nearestopsmap = state.neareststops.map((edge, i) => {
                if (edge.node != null && edge.node.place != null && edge.node.place != undefined
                  && edge.node.place.locationType != null && edge.node.place.locationType != undefined)
               return (
                <li  ><NearStop index={i} stop={edge.node} 
                seeKAllStopTimes={this.state.seeKAllStopTimes}/></li>
               ); 
             } 
             );

             let uncheckCheckBox = (state.uncheckCheckBox);
             if (Config.bDebug)
             console.log("uncheckCheckBox");
             if (Config.bDebug)
             console.log(uncheckCheckBox);
             
             let features3 = <Checkbox id="idChecboxShowAllStopTimes" 
                 label="Hae kaikkien pysäkkien pysähtymisajat" 
                 handleCheckboxChange={this.handleChecboxShowAllStopTimes} 
                 isChecked={uncheckCheckBox == true ? false : state.seeKAllStopTimes} 
                 />;

          //  if (!neareststops)
            this.prev_feature = state.addressfeatures;              
            return (
                <div data-message="tulokset">
                <h3>{state.address}:n pysäkit (pit {props.longitude} lev {props.latitude})</h3>
                {features3}
                <p></p>
                {loadingComp}
                {features2}
                <ul role="listbox" aria-label="reittiehdotuksia">
                  {this.nearestopsmap}</ul>
                </div>
            );
       }
        else
        return (
            <div>
            </div>
        );
    }
}

//export default  withApollo(SearchAndListAddressStops);
export default  SearchAndListAddressStops;
